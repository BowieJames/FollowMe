#include <SPI.h>
#include "DW1000Ranging.h"
#include "DW1000.h"

// FRONT anchor address and delay
char anchor_addr[] = "83:00:5B:D5:A9:9A:E2:9C";
uint16_t Adelay = 16607;

// Triangle geometry: side length 5cm (assumed)
const float d = 0.05f, h = d * 0.866f; // h = d * sqrt(3)/2

// DW1000 pins for ESP32
#define SPI_SCK 18
#define SPI_MISO 19
#define SPI_MOSI 23
const uint8_t PIN_RST = 27, PIN_IRQ = 34, PIN_SS = 4;

// UART pins for slaves
const int UART1_RX = 21, UART1_TX = 22; // LEFT
const int UART2_RX = 16, UART2_TX = 17; // RIGHT

struct Sample {
  uint16_t tag;
  float dist;
  uint32_t t_ms;
  bool valid;
};
Sample localF, remoteL, remoteR;

String uartLine1, uartLine2;
const uint32_t MATCH_WINDOW_MS = 50;

bool nearlySimultaneous() {
  if (!localF.valid || !remoteL.valid || !remoteR.valid) return false;
  if (localF.tag != remoteL.tag || localF.tag != remoteR.tag) return false;
  uint32_t min_t = min(localF.t_ms, min(remoteL.t_ms, remoteR.t_ms));
  uint32_t max_t = max(localF.t_ms, max(remoteL.t_ms, remoteR.t_ms));
  return max_t - min_t <= MATCH_WINDOW_MS;
}

// Relative distance from centre of triangle spread out 5cm apart at 60 degree equalteral inside angles. (0 degrees to the left) , (90 degrees in the front), (180 degrees to right) 

void computeAndPrint() {
  float rL = remoteL.dist, rR = remoteR.dist, rF = localF.dist;
  float x = (rL*rL - rR*rR) / (2.0f * d);
  float term = rL*rL - (x + 0.5f*d)*(x + 0.5f*d);
  if (term < -0.0001f) return;
  float y = sqrtf(max(0.0f, term));
  if (fabs(sqrtf(x*x + (y - h)*(y - h)) - rF) > 0.05f) return;
  float distance = sqrtf(x*x + (y - h/3.0f)*(y - h/3.0f));
  float angleL = 180.0f - atan2f(y, x) * 57.29578f;
  angleL = constrain(angleL, 0.0f, 180.0f);
  Serial.printf("distance=%.3f m, angle=%.1f deg\n", distance, angleL);
}

void setup() {
  Serial.begin(115200);
  Serial1.begin(115200, SERIAL_8N1, UART1_RX, UART1_TX);
  Serial2.begin(115200, SERIAL_8N1, UART2_RX, UART2_TX);
  SPI.begin(SPI_SCK, SPI_MISO, SPI_MOSI);
  DW1000Ranging.initCommunication(PIN_RST, PIN_SS, PIN_IRQ);
  DW1000.setAntennaDelay(Adelay);
  DW1000Ranging.attachNewRange(newRange);
  DW1000Ranging.startAsAnchor(anchor_addr, DW1000.MODE_LONGDATA_RANGE_LOWPOWER, false);
}

void loop() {
  DW1000Ranging.loop();

  // Read LEFT anchor
  while (Serial1.available()) {
    char c = Serial1.read();
    if (c == '\n') {
      if (uartLine1.startsWith("ANCH,")) {
        uint16_t a, t;
        float dd;
        if (sscanf(uartLine1.c_str(), "ANCH,%hx,%hx,%f", &a, &t, &dd) == 3) {
          remoteL = {t, dd, millis(), true};
          if (nearlySimultaneous()) computeAndPrint();
        }
      }
      uartLine1 = "";
    } else if (c != '\r') {
      uartLine1 += c;
    }
  }

  // Read RIGHT anchor
  while (Serial2.available()) {
    char c = Serial2.read();
    if (c == '\n') {
      if (uartLine2.startsWith("ANCH,")) {
        uint16_t a, t;
        float dd;
        if (sscanf(uartLine2.c_str(), "ANCH,%hx,%hx,%f", &a, &t, &dd) == 3) {
          remoteR = {t, dd, millis(), true};
          if (nearlySimultaneous()) computeAndPrint();
        }
      }
      uartLine2 = "";
    } else if (c != '\r') {
      uartLine2 += c;
    }
  }
}

void newRange() {
  localF = {DW1000Ranging.getDistantDevice()->getShortAddress(), 
            DW1000Ranging.getDistantDevice()->getRange(), 
            millis(), true};
  if (nearlySimultaneous()) computeAndPrint();
}

void newDevice(DW1000Device*) {}
void inactiveDevice(DW1000Device*) {}