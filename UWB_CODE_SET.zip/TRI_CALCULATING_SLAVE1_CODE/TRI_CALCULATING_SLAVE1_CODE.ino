#include <SPI.h>
#include "DW1000Ranging.h"
#include "DW1000.h"

// LEFT anchor settings
char anchor_addr[] = "84:00:5B:D5:A9:9A:E2:9D"; // Unique for LEFT
uint16_t Adelay = 16615;

// DW1000 pins
#define SPI_SCK 18
#define SPI_MISO 19
#define SPI_MOSI 23
const uint8_t PIN_RST = 27, PIN_IRQ = 34, PIN_SS = 4;

// UART1 pins (to master)
const int UART1_TX = 21, UART1_RX = 22;

void setup() {
  Serial2.begin(115200, SERIAL_8N1, UART1_RX, UART1_TX);
  SPI.begin(SPI_SCK, SPI_MISO, SPI_MOSI);
  DW1000Ranging.initCommunication(PIN_RST, PIN_SS, PIN_IRQ);
  DW1000.setAntennaDelay(Adelay);
  DW1000Ranging.attachNewRange(newRange);
  DW1000Ranging.startAsAnchor(anchor_addr, DW1000.MODE_LONGDATA_RANGE_LOWPOWER, false);
}

void loop() {
  DW1000Ranging.loop();
}

void newRange() {
  uint16_t tagShort = DW1000Ranging.getDistantDevice()->getShortAddress();
  float dist = DW1000Ranging.getDistantDevice()->getRange();
  uint16_t myShort = (strtol(anchor_addr + 15, NULL, 16) << 8) | strtol(anchor_addr + 18, NULL, 16);
  Serial2.printf("ANCH,%04X,%04X,%.3f\n", myShort, tagShort, dist);
}